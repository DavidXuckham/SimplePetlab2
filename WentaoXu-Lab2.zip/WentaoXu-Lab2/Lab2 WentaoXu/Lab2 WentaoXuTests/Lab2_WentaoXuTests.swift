//
//  Lab2_WentaoXuTests.swift
//  Lab2 WentaoXuTests
//
//  Created by labuser on 9/21/18.
//  Copyright © 2018 WentaoXu. All rights reserved.
//

import XCTest
@testable import Lab2_WentaoXu

class Lab2_WentaoXuTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
    
}
